# Mall Customer Segmentation Using K-Means Clustering

## Project Overview

This project uses the K-Means Clustering algorithm to segment mall customers into different groups based on their Annual Income and Spending Score.

## Objective

To identify customer groups with similar purchasing behavior and spending patterns.

## Dataset

Mall Customer Dataset

Features Used:

* Annual Income (k$)
* Spending Score (1-100)

## Technologies Used

* Python
* Pandas
* Matplotlib
* Scikit-Learn

## Algorithm

K-Means Clustering

## Steps Performed

1. Loaded the dataset.
2. Selected Annual Income and Spending Score as features.
3. Applied K-Means clustering with 5 clusters.
4. Assigned customers to clusters.
5. Visualized the clusters using a scatter plot.

## Output

The algorithm groups customers into different clusters such as:

* High Income – High Spending
* High Income – Low Spending
* Low Income – High Spending
* Low Income – Low Spending
* Average Customers

## Conclusion

K-Means Clustering helps businesses understand customer behavior and create targeted marketing strategies for different customer segments.
