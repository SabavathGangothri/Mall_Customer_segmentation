import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

# Load Dataset
df = pd.read_csv("Mall_Customers.csv")

# Display first 5 records
print("First 5 Records:")
print(df.head())

# Select Features
X = df[['Annual Income (k$)', 'Spending Score (1-100)']]

# Create K-Means Model
kmeans = KMeans(n_clusters=5, random_state=42)

# Fit Model and Predict Clusters
df['Cluster'] = kmeans.fit_predict(X)

# Display Clustered Data
print("\nClustered Data:")
print(df.head())

# Plot Clusters
plt.figure(figsize=(8, 6))

plt.scatter(
    X['Annual Income (k$)'],
    X['Spending Score (1-100)'],
    c=df['Cluster']
)

# Plot Centroids
plt.scatter(
    kmeans.cluster_centers_[:, 0],
    kmeans.cluster_centers_[:, 1],
    s=200,
    marker='X'
)

plt.title("Customer Segmentation using K-Means")
plt.xlabel("Annual Income (k$)")
plt.ylabel("Spending Score (1-100)")
plt.grid(True)

plt.show()